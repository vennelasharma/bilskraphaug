package vehicles;

// Representerer et skraphandlersted.
// Automatisk generer konstruktør, getters, tostring, equals og hashCode.
// Brukes i import av scrapyards fra fil til database

public record Scrapyard(int id, String name, String address, String phoneNumber) {}