package vehicles;

// Representerer en fossilbil med drivstofftype og mengde.

public class FossilCar extends Vehicle {
    private String fuelType;
    private int fuelAmount;

    public FossilCar(int vehicleId, int scrapyardId, String brand, String model, int yearModel,
                     String registrationNumber, String chassisNumber, boolean driveable,
                     int numberOfSellableWheels, String fuelType, int fuelAmount) {
        super(vehicleId, scrapyardId, brand, model, yearModel, registrationNumber, chassisNumber, driveable, numberOfSellableWheels);
        this.fuelType = fuelType;
        this.fuelAmount = fuelAmount;
    }

    public String getFuelType() { return fuelType; }
    public int getFuelAmount() { return fuelAmount; }
}
