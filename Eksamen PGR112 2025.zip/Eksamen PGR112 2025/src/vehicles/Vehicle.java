package vehicles;

// Abstrakt superklasse for alle typer kjøretøy
// Felles attributter og metoder for Fossilcar, ElectricCar og Motorcycle.

public abstract class Vehicle {
    protected int vehicleId;
    protected int scrapyardId;
    protected String brand;
    protected String model;
    protected int yearModel;
    protected String registrationNumber;
    protected String chassisNumber;
    protected boolean driveable;
    protected int numberOfSellableWheels;

    public Vehicle(int vehicleId, int scrapyardId, String brand, String model, int yearModel,
                   String registrationNumber, String chassisNumber, boolean driveable, int numberOfSellableWheels) {
        this.vehicleId = vehicleId;
        this.scrapyardId = scrapyardId;
        this.brand = brand;
        this.model = model;
        this.yearModel = yearModel;
        this.registrationNumber = registrationNumber;
        this.chassisNumber = chassisNumber;
        this.driveable = driveable;
        this.numberOfSellableWheels = numberOfSellableWheels;
    }

    public int getVehicleId() { return vehicleId; }
    public int getScrapyardId() { return scrapyardId; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public int getYearModel() { return yearModel; }
    public String getRegistrationNumber() { return registrationNumber; }
    public String getChassisNumber() { return chassisNumber; }
    public boolean isDriveable() { return driveable; }
    public int getNumberOfSellableWheels() { return numberOfSellableWheels; }
}
