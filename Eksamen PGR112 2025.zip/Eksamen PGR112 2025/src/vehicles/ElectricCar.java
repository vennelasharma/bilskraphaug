package vehicles;

// Representerer en elbil med batterikapasitet og ladenivå.
public class ElectricCar extends Vehicle {
    private int batteryCapacity;
    private int chargeLevel;

    public ElectricCar(int vehicleId, int scrapyardId, String brand, String model, int yearModel,
                       String registrationNumber, String chassisNumber, boolean driveable,
                       int numberOfSellableWheels, int batteryCapacity, int chargeLevel) {
        super(vehicleId, scrapyardId, brand, model, yearModel, registrationNumber, chassisNumber, driveable, numberOfSellableWheels);
        this.batteryCapacity = batteryCapacity;
        this.chargeLevel = chargeLevel;
    }

    public int getBatteryCapacity() { return batteryCapacity; }
    public int getChargeLevel() { return chargeLevel; }
}
