package vehicles;

// Representerer en motorsykkel med ekstra felt som sidevogn, modifisering og hjul.
public class Motorcycle extends Vehicle {
    private boolean hasSidecar;
    private int engineCapacity;
    private boolean isModified;
    private int numberOfWheels;

    public Motorcycle(int vehicleId, int scrapyardId, String brand, String model, int yearModel,
                      String registrationNumber, String chassisNumber, boolean driveable,
                      int numberOfSellableWheels, boolean hasSidecar, int engineCapacity,
                      boolean isModified, int numberOfWheels) {
        super(vehicleId, scrapyardId, brand, model, yearModel, registrationNumber, chassisNumber, driveable, numberOfSellableWheels);
        this.hasSidecar = hasSidecar;
        this.engineCapacity = engineCapacity;
        this.isModified = isModified;
        this.numberOfWheels = numberOfWheels;
    }

    public boolean hasSidecar() { return hasSidecar; }
    public int getEngineCapacity() { return engineCapacity; }
    public boolean isModified() { return isModified; }
    public int getNumberOfWheels() { return numberOfWheels; }
}
