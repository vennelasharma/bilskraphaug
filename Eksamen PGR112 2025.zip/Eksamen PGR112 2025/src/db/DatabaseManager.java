package db; //  Klassen tilhører pakken "db", som håndterer databasekoblinger

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

// Leser database-tilkoblingsinfo fra db.properties og oppretter JDBC-tilkobling.

public class DatabaseManager {

    // Lager en statisk properties objekt som holder på brukernavn, passord og URL
    private static final Properties props = new Properties();

    // Leser db.properties filen og laster inn verdiene
    static {
        try (FileReader reader = new FileReader("db.properties")) {
            props.load(reader);
        } catch (Exception e) {
            System.out.println("Kunne ikke laste db.properties: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                props.getProperty("url"), // Leser inn database-URL
                props.getProperty("user"), // Leser inn brukernavn (sensor må legge inn i properties fila)
                props.getProperty("password") // Leser inn passord (sensor må legge inn i properties fila)
        );
    }
}
