package ui;

// Del 2: Hovedmeny og brukerinteraksjon.
// Databasen er fylt via Importer.java, så importkode er fjernet her.

public class Main {
    public static void main(String[] args) {
        Menu.showMenu(); // Meny vises i egen klasse
    }
}
