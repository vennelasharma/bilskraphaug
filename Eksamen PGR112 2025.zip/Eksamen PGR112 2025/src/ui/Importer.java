package ui;

import db.DatabaseManager;
import vehicles.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;


 // Denne klassen ble brukt for å utføre Del 1:
 // Leser inn data fra vehicles.txt og lagrer informasjonen i databasen.
 // Kjøres kun én gang. Kommentert ut fra Main for å unngå duplikater. Ikke brukt i DEL 2

public class Importer {

    public static void main(String[] args) {
        // Leser inn alle scrapyards fra filen
        List<Scrapyard> scrapyards = readScrapyardsFromFile("vehicles.txt");
        insertScrapyardsToDB(scrapyards); // Lagrer scrapyards i databasen

        // Leser inn alle kjøretøy fra filen
        List<Vehicle> vehicles = readVehiclesFromFile("vehicles.txt");
        insertVehiclesToDB(vehicles); // Lagrer kjøretøy i databasen
    }

    // Leser informasjon om scrapyards fra filen og returnerer en liste med Scrapyard-objekter
    public static List<Scrapyard> readScrapyardsFromFile(String filePath) {
        List<Scrapyard> scrapyards = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            int count = Integer.parseInt(br.readLine().trim());

            for (int i = 0; i < count; i++) {
                int id = Integer.parseInt(br.readLine().trim());
                String name = br.readLine().trim();
                String address = br.readLine().trim();
                String phoneNumber = br.readLine().trim();
                scrapyards.add(new Scrapyard(id, name, address, phoneNumber));

                br.readLine(); // Leser "---" som skille
            }
        } catch (IOException e) {
            System.out.println("Feil ved lesing av scrapyards: " + e.getMessage());
        }
        return scrapyards;
    }

    // Setter inn scrapyard-objektene i databasen med JDBC
    public static void insertScrapyardsToDB(List<Scrapyard> scrapyards) {
        String sql = "INSERT INTO Scrapyard (ScrapyardID, Name, Address, PhoneNumber) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (Scrapyard s : scrapyards) {
                stmt.setInt(1, s.id());
                stmt.setString(2, s.name());
                stmt.setString(3, s.address());
                stmt.setString(4, s.phoneNumber());
                stmt.executeUpdate(); // Sender inn raden til databasen
            }
            System.out.println("Scrapyards lagt inn i databasen.");

        } catch (Exception e) {
            System.out.println("Feil ved innsetting i databasen: " + e.getMessage());
        }
    }

    // Leser informasjon om alle kjøretøy (av tre ulike typer) fra fil.
    // Returnerer en liste med Vehicle-objekter (bruker arv).
    public static List<Vehicle> readVehiclesFromFile(String filePath) {
        List<Vehicle> vehicles = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            // Hopper over scrapyard delen først
            int scrapyardCount = Integer.parseInt(br.readLine().trim());
            for (int i = 0; i < scrapyardCount * 5; i++) {
                br.readLine();
            }

            int vehicleCount = Integer.parseInt(br.readLine().trim());

            for (int i = 0; i < vehicleCount; i++) {
                // Felles attributter for alle kjøretøy
                int vehicleId = Integer.parseInt(br.readLine().trim());
                int scrapyardId = Integer.parseInt(br.readLine().trim());
                String type = br.readLine().trim();
                String brand = br.readLine().trim();
                String model = br.readLine().trim();
                int yearModel = Integer.parseInt(br.readLine().trim());
                String registrationNumber = br.readLine().trim();
                String chassisNumber = br.readLine().trim();
                boolean driveable = Boolean.parseBoolean(br.readLine().trim());
                int numberOfSellableWheels = Integer.parseInt(br.readLine().trim());

                // Leser spesifikke attributter avhengig av type
                switch (type) {
                    case "FossilCar" -> {
                        String fuelType = br.readLine().trim();
                        int fuelAmount = Integer.parseInt(br.readLine().trim());
                        vehicles.add(new FossilCar(vehicleId, scrapyardId, brand, model, yearModel,
                                registrationNumber, chassisNumber, driveable, numberOfSellableWheels, fuelType, fuelAmount));
                    }

                    case "ElectricCar" -> {
                        int batteryCapacity = Integer.parseInt(br.readLine().trim());
                        int chargeLevel = Integer.parseInt(br.readLine().trim());
                        vehicles.add(new ElectricCar(vehicleId, scrapyardId, brand, model, yearModel,
                                registrationNumber, chassisNumber, driveable, numberOfSellableWheels, batteryCapacity, chargeLevel));
                    }

                    case "Motorcycle" -> {
                        boolean hasSidecar = Boolean.parseBoolean(br.readLine().trim());
                        int engineCapacity = Integer.parseInt(br.readLine().trim());
                        boolean isModified = Boolean.parseBoolean(br.readLine().trim());
                        int numberOfWheels = Integer.parseInt(br.readLine().trim());
                        vehicles.add(new Motorcycle(vehicleId, scrapyardId, brand, model, yearModel,
                                registrationNumber, chassisNumber, driveable, numberOfSellableWheels,
                                hasSidecar, engineCapacity, isModified, numberOfWheels));
                    }
                }

                br.readLine(); // Leser "---" mellom kjøretøy
            }

        } catch (IOException e) {
            System.out.println("Feil ved lesing av kjøretøy: " + e.getMessage());
        }

        return vehicles;
    }

    // Setter inn kjøretøyene i riktige tabeller basert på kjøretøytype.
    // Bruker instanceof og innkapsling

    public static void insertVehiclesToDB(List<Vehicle> vehicles) {
        try (Connection conn = DatabaseManager.getConnection()) {

            for (Vehicle v : vehicles) {
                if (v instanceof FossilCar fc) {
                    String sql = "INSERT INTO FossilCar (VehicleID, Brand, Model, YearModel, RegistrationNumber, ChassisNumber, Driveable, NumberOfSellableWheels, ScrapyardID, FuelType, FuelAmount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, fc.getVehicleId());
                        stmt.setString(2, fc.getBrand());
                        stmt.setString(3, fc.getModel());
                        stmt.setInt(4, fc.getYearModel());
                        stmt.setString(5, fc.getRegistrationNumber());
                        stmt.setString(6, fc.getChassisNumber());
                        stmt.setBoolean(7, fc.isDriveable());
                        stmt.setInt(8, fc.getNumberOfSellableWheels());
                        stmt.setInt(9, fc.getScrapyardId());
                        stmt.setString(10, fc.getFuelType());
                        stmt.setInt(11, fc.getFuelAmount());
                        stmt.executeUpdate();
                    }

                } else if (v instanceof ElectricCar ec) {
                    String sql = "INSERT INTO ElectricCar (VehicleID, Brand, Model, YearModel, RegistrationNumber, ChassisNumber, Driveable, NumberOfSellableWheels, ScrapyardID, BatteryCapacity, ChargeLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, ec.getVehicleId());
                        stmt.setString(2, ec.getBrand());
                        stmt.setString(3, ec.getModel());
                        stmt.setInt(4, ec.getYearModel());
                        stmt.setString(5, ec.getRegistrationNumber());
                        stmt.setString(6, ec.getChassisNumber());
                        stmt.setBoolean(7, ec.isDriveable());
                        stmt.setInt(8, ec.getNumberOfSellableWheels());
                        stmt.setInt(9, ec.getScrapyardId());
                        stmt.setInt(10, ec.getBatteryCapacity());
                        stmt.setInt(11, ec.getChargeLevel());
                        stmt.executeUpdate();
                    }

                } else if (v instanceof Motorcycle mc) {
                    String sql = "INSERT INTO Motorcycle (VehicleID, Brand, Model, YearModel, RegistrationNumber, ChassisNumber, Driveable, NumberOfSellableWheels, ScrapyardID, HasSidecar, EngineCapacity, IsModified, NumberOfWheels) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, mc.getVehicleId());
                        stmt.setString(2, mc.getBrand());
                        stmt.setString(3, mc.getModel());
                        stmt.setInt(4, mc.getYearModel());
                        stmt.setString(5, mc.getRegistrationNumber());
                        stmt.setString(6, mc.getChassisNumber());
                        stmt.setBoolean(7, mc.isDriveable());
                        stmt.setInt(8, mc.getNumberOfSellableWheels());
                        stmt.setInt(9, mc.getScrapyardId());
                        stmt.setBoolean(10, mc.hasSidecar());
                        stmt.setInt(11, mc.getEngineCapacity());
                        stmt.setBoolean(12, mc.isModified());
                        stmt.setInt(13, mc.getNumberOfWheels());
                        stmt.executeUpdate();
                    }
                }
            }

            System.out.println("Kjøretøy lagt inn i databasen.");

        } catch (Exception e) {
            System.out.println("Feil ved innsetting av kjøretøy: " + e.getMessage());
        }
    }
}
