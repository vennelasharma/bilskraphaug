package ui;

import db.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

// Del 2: Menyprogram som lar brukeren hente ut data fra databasen.

public class Menu {

    // Viser hovedmenyen og lar brukeren velge handling
    // Kjører i løkke helt til brukeren velger å avslutte

    public static void showMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = -1; // Initialiseres for å unngå kompliatorfeil

        do {
            // Viser tilgjengelige valg i menyen
            System.out.println("--- MENY ---");
            System.out.println("1. Vis alle kjøretøy");
            System.out.println("2. Total mengde drivstoff i FossilCars");
            System.out.println("3. Vis alle kjørbare kjøretøy");
            System.out.println("4. Vis kjøretøy i valgt scrapyard");
            System.out.println("5. Avslutt");
            System.out.print("Velg: ");

            try {
                choice = Integer.parseInt(scanner.nextLine()); // Leser brukerens valg
            } catch (NumberFormatException e) {
                System.out.println("Ugyldig input. Skriv et tall.");
                continue; // Hopper over resten av løkka og tilbake til meny
            }

            // Utfører handling basert på brukerens valg
            switch (choice) {
                case 1 -> showAllVehicles();
                case 2 -> showTotalFuel();
                case 3 -> showDriveableVehicles();
                case 4 -> showVehiclesByScrapyard(scanner);
                case 5 -> System.out.println("Avslutter...");
                default -> System.out.println("Ugyldig valg, prøv igjen.");
            }

        } while (choice != 5);

        scanner.close(); // Lukker scanner objektet når programmet avsluttes.

    }

    // Menyvalg 1: Viser alle kjøretøy fra alle tre tabeller.

    private static void showAllVehicles() {
        System.out.println("--- Alle kjøretøy ---");

        try (Connection conn = DatabaseManager.getConnection()) {
            // Henter kjøretøy fra tre forskjellige tabeller
            String[] queries = {
                    "SELECT * FROM FossilCar",
                    "SELECT * FROM ElectricCar",
                    "SELECT * FROM Motorcycle"
            };

            for (String query : queries) {
                try (PreparedStatement stmt = conn.prepareStatement(query);
                     ResultSet rs = stmt.executeQuery()) {

                    // Går gjennom alle rader i resultatet
                    while (rs.next()) {
                        int id = rs.getInt("VehicleID");
                        String brand = rs.getString("Brand");
                        String model = rs.getString("Model");
                        int year = rs.getInt("YearModel");
                        boolean driveable = rs.getBoolean("Driveable");
                        int scrapyardId = rs.getInt("ScrapyardID");

                        // Bruker tabellnavn til å identifisere type kjøretøy
                        String type = query.contains("FossilCar") ? "FossilCar"
                                : query.contains("ElectricCar") ? "ElectricCar"
                                : "Motorcycle";

                        // Skriver ut informasjonen
                        System.out.println("[" + type + "] ID: " + id +
                                ", " + brand + " " + model + " (" + year + ")" +
                                ", Kjørbar: " + (driveable ? "Ja" : "Nei") +
                                ", ScrapyardID: " + scrapyardId);
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("Feil ved visning av kjøretøy: " + e.getMessage());
        }
    }


    // Menyvalg 2: Viser hvor mye drivstoff som befinner seg i fossillbilene totalt.
    private static void showTotalFuel() {
        System.out.println("\n--- Total mengde drivstoff i FossilCars ---");

        // SQL for å summere kolonnen FuelAmount
        String sql = "SELECT SUM(FuelAmount) AS TotalFuel FROM FossilCar";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                int total = rs.getInt("TotalFuel"); // Leser summen
                System.out.println("Totalt drivstoffmengde i fossillbilene: " + total + " liter.");
            } else {
                System.out.println("Fant ingen FossilCars.");
            }

        } catch (Exception e) {
            System.out.println("Feil ved henting av drivstoffmengde: " + e.getMessage());
        }
    }

    // Menyvalg 3: Viser informasjon om alle kjøretøy som er kjørbare
    private static void showDriveableVehicles() {
        System.out.println("\n--- Kjørbare kjøretøy ---");

        // Samme spørring mot alle tre tabeller, men filtrert på Driveable=true
        String[] queries = {
                "SELECT * FROM FossilCar WHERE Driveable = true",
                "SELECT * FROM ElectricCar WHERE Driveable = true",
                "SELECT * FROM Motorcycle WHERE Driveable = true"
        };

        try (Connection conn = DatabaseManager.getConnection()) {
            for (String query : queries) {
                try (PreparedStatement stmt = conn.prepareStatement(query);
                     ResultSet rs = stmt.executeQuery()) {

                    while (rs.next()) {
                        int id = rs.getInt("VehicleID");
                        String brand = rs.getString("Brand");
                        String model = rs.getString("Model");
                        int year = rs.getInt("YearModel");

                        // Bestemmer type basert på tabell
                        String type = query.contains("FossilCar") ? "FossilCar"
                                : query.contains("ElectricCar") ? "ElectricCar"
                                : "Motorcycle";

                        System.out.println("[" + type + "] ID: " + id + ", " + brand + " " + model + " (" + year + ")");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Feil ved henting av kjørbare kjøretøy: " + e.getMessage());
        }
    }

    // Menyvalg 4: Valgfri funskjonalitet
    // Lar brukeren taste inn scrapeyard ID og viser alle kjøretøy derfra
    private static void showVehiclesByScrapyard(Scanner scanner) {
        System.out.print("\nSkriv inn ScrapyardID (f.eks. 1, 2 eller 3): ");
        String input = scanner.nextLine();

        int id;
        try {
            id = Integer.parseInt(input); // Konverterer brukerinput til tall
        } catch (NumberFormatException e) {
            System.out.println("Ugyldig tall. Prøv igjen.");
            return;
        }

        System.out.println("\n--- Kjøretøy i Scrapyard ID " + id + " ---");

        // Samme spørring mot alle tre tabeller, filtrert på scrapyardID som bruker har valgt
        String[] queries = {
                "SELECT * FROM FossilCar WHERE ScrapyardID = ?",
                "SELECT * FROM ElectricCar WHERE ScrapyardID = ?",
                "SELECT * FROM Motorcycle WHERE ScrapyardID = ?"
        };

        // Henter ut data fra database
        try (Connection conn = DatabaseManager.getConnection()) {
            // Går gjennom alle tabellene
            for (String query : queries) {
                // Forbedrer en SQL spørring med parametere for hver tabell
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, id); // Setter parameter i WHERE
                    // Utfører spørringen
                    try (ResultSet rs = stmt.executeQuery()) {
                        // Går gjennom alle rader som ble funnet i den aktuelle tabllen
                        while (rs.next()) {
                            int vehicleId = rs.getInt("VehicleID");
                            String brand = rs.getString("Brand");
                            String model = rs.getString("Model");
                            int year = rs.getInt("YearModel");

                            // Finner ut hvilket type kjøretøy det er
                            String type = query.contains("FossilCar") ? "FossilCar"
                                    : query.contains("ElectricCar") ? "ElectricCar"
                                    : "Motorcycle";

                            System.out.println("[" + type + "] ID: " + vehicleId + ", " + brand + " " + model + " (" + year + ")");
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Feil ved henting av kjøretøy for scrapyard " + id + ": " + e.getMessage());
        }
    }
}
